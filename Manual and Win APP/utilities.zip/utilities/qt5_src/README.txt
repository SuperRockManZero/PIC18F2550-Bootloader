The application in this folder was build with QT, an open source cross-platform enviornment.  
The license information for QT and its components can be found at http://qt-project.org/


This project was built and tested with the Qt 5.0.2 for Windows 32-bit (using the MinGW 4.7 compiler).
The project has not been tested with other versions of Qt or with the MSVC compiler.