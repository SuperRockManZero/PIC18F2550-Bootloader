
#define APPLICATION "USB Bootloader"
#define VERSION     "2.9j"
